<?php
require_once 'function.php';
$openid="abc";
$wx_nickname="游客";
$wx_headimgurl="img/head.jpg";
if(empty($_GET["belong"])){
	$belong='0';
}else{
	$belong=$_GET["belong"];
}
if(empty($openid)){
	exit();
}else{
	require_once 'mysqli.php';
	//查询人数；$total['total']
	$sql = "select heart from games_sdddp where openid = '$openid'";
	$res = $_mysqli->query($sql);
	$total = $res -> fetch_assoc();
	if(empty($total['heart'])){
		$wx_heart = '5';
	}else{
		$wx_heart = $total['heart'];
	}
	$_mysqli->close();
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
	<title>圣诞对对碰</title>
    <!-- 默认极速核心 -->
    <meta name="renderer" content="webkit"/>
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
	<!-- Add to homescreen for Chrome on Android -->
	<meta name="mobile-web-app-capable" content="yes"/>
	<!-- Add to homescreen for Safari on iOS -->
	<meta name="apple-mobile-web-app-capable" content="yes"/>
	<meta name="apple-mobile-web-app-status-bar-style" content="black"/>
	<link rel="stylesheet" href="zui/css/zui.min.css"/>
	<link rel="stylesheet" href="zui/css/common.css"/>
	<link rel="stylesheet" href="index.css"/>
</head>
<body id="divSnow-1">
<div class="m">
	<div class="gamelogo"><img src="img/title.png" class="wow fadeInDown"></div>
	<div class="gameml"><img src="img/ml.png"  class="wow bounceInRight"></div>
	<a class="gamean musicAn1" href="game.php">
		<h3>进入游戏</h3>
		<img src="zui/img/an.png">
	</a>
	<a class="gamean musicAn1" data-remote="explain.php" data-toggle="modal" data-title="游戏说明">
		<h3>游戏说明</h3>
		<img src="zui/img/an.png">
	</a>
	<a class="gamean musicAn1" data-remote="ranking.php?openid=<?=$openid?>&belong=<?=$belong?>" data-toggle="modal" data-title="排行榜">
		<h3>排行榜</h3>
		<img src="zui/img/an.png">
	</a>
	<a class="gamean musicAn1" href="javascript:void(0)" id="share">
		<h3>找朋友比赛</h3>
		<img src="zui/img/an.png">
	</a>
	
	<div id="musicControl" class="wow bounceIn" data-wow-delay=".8s">
		<a href="javascript:void(0)" id="mc_play" class="stop" onclick="play_music();">
			<audio id="musicfx" loop>
				<source src="img/music.mp3" type="audio/mpeg">
			</audio>
		</a>
	</div>
</div>
<div class="game-footer">
	技术支持：QQ75943938
</div>
<div class="an-share-wk">
 	<img src="zui/img/fenxiang.png">
</div>

<div id="musicAn1">
	<audio id="musican1">
		<source src="zui/img/an1.mp3" type="audio/mpeg">
	</audio>
</div>
<div id="musicAn2">
	<audio id="musican2">
		<source src="zui/img/an2.mp3" type="audio/mpeg">
	</audio>
</div>
	
<div id="divSnow-1" class="htmleaf-content canvas-1"></div>
<script src="zui/lib/jquery/jquery.js"></script>
<script src="zui/js/zui.min.js"></script>
<script src="zui/js/common.js"></script>
<script src="js/Websnowjq.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("#divSnow-1").websnowjq();
	$('#share').click(function() {
		$('.an-share-wk').addClass('active');
	});
	$('.an-share-wk').click(function() {
		$('.an-share-wk').removeClass('active');
	});
});
</script>
</body>
</html>