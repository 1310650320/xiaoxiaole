<?php
require_once 'function.php';
$openid="abc";
$wx_nickname="游客";
$wx_headimgurl="img/head.jpg";
if(empty($_GET["belong"])){
	$belong='0';
}else{
	$belong=$_GET["belong"];
}
if(empty($openid)){
	exit();
}else{
	require_once 'mysqli.php';
	//查询人数；$total['total']
	$sql = "select score,heart from games_sdddp where openid = '$openid'";
	$res = $_mysqli->query($sql);
	$total = $res -> fetch_assoc();
	
	if(empty($total['score'])){
		$wx_heart = '5';
	}else{
		$wx_heart = $total['heart'];
	}
	$_mysqli->close();
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="target-densitydpi=device-dpi,width=520,user-scalable=no">
	<title>圣诞对对碰</title>
    <!-- 默认极速核心 -->
    <meta name="renderer" content="webkit"/>
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
	<!-- Add to homescreen for Chrome on Android -->
	<meta name="mobile-web-app-capable" content="yes"/>
	<!-- Add to homescreen for Safari on iOS -->
	<meta name="apple-mobile-web-app-capable" content="yes"/>
	<meta name="apple-mobile-web-app-status-bar-style" content="black"/>
	<link rel="stylesheet" href="zui/css/zui.min.css"/>
	<link rel="stylesheet" href="zui/css/common.css"/>
	<link rel="stylesheet" href="style.css"/>
</head>
<body id="divSnow-1">
<div id="stage">
	<div class="lipin">
		<span id="score">0</span>
		<img src="img/lipin.png">
	</div>
	<div class="progress progress-striped active" id="time">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width:100%">
		</div>
		<div id="progress-text"></div>
		<img src="img/nl.png">
	</div>
	<div id="grid"></div>
</div>

<div class="layer" id="startLayer">
	<div class="layer-ul wow fadeInDown">
		<h3><img src="img/xin.png"> 可玩次数：<span><?=$wx_heart?></span></h3>
		<h4>分享给好友，朋友参与游戏即可多获取一次游戏机会！</h4>
		<button type="button" class="btn btn-danger musicAn2" id="btnStart">开始挑战</button>&nbsp;&nbsp;
		<button type="button" id="share" class="btn btn-warning musicAn1">分享好友</button>
	</div>
	<img src="img/tc.png" class="wow fadeInDown">
</div>
<div class="layer" id="overLayer">
	<div class="layer-ul wow fadeInDown">
		<h3><img src="img/xin.png"> 可玩次数：<span id="startHeart"><?=$wx_heart?></span></h3>
		<h4>分享给好友，朋友参与游戏即可多获取一次游戏机会！</h4>
		<button type="button" class="btn btn-danger musicAn2" id="btnAgain">再来一次</button>&nbsp;&nbsp;
		<button type="button" id="share" class="btn btn-warning musicAn1">分享好友</button>
	</div>
	<img src="img/tc.png" class="wow fadeInDown">
</div>
	
<div class="an-share-wk">
 	<img src="zui/img/fenxiang.png">
</div>
<div class="an-victory-wk">
 	<div align="right"><img src="zui/img/fenxiang.png"></div>
	<div class="an-victory-bt"><img src="zui/img/success.png"></div>
	<div class="an-victory-tx"><img src="<?=$wx_headimgurl?>"></div>
	<div class="an-victory-wz">
		<h3>恭喜超过自己最好成绩</h3>
		<p>当前得分，当前排名</p>
		<a href="index.php" class="btn btn-danger break" type="button">确定</a>
	</div>
	<div class="an-victory-sg"><img src="zui/img/light.png"></div>
</div>
<div class="fanhui">
	<a href="index.php" class="wow bounceIn" data-wow-delay="1s"><img src="img/fh.png"></a>
</div>
<div id="musicControl" class="wow bounceIn" data-wow-delay=".8s">
	<a href="javascript:void(0)" id="mc_play" class="stop" onclick="play_music();">
		<audio id="musicfx" loop>
			<source src="img/game.mp3" type="audio/mpeg">
		</audio>
	</a>
</div>
<div id="musicAn1">
	<audio id="musican1">
		<source src="zui/img/an1.mp3" type="audio/mpeg">
	</audio>
</div>
<div id="musicAn2">
	<audio id="musican2">
		<source src="zui/img/an2.mp3" type="audio/mpeg">
	</audio>
</div>

<div style="display: none;">
	<audio id="music_move">
		<source src="img/yidong.mp3" type="audio/mpeg">
	</audio>
	<audio id="music_error">
		<source src="img/cuowu.mp3" type="audio/mpeg">
	</audio>
	<audio id="music_remove">
		<source src="img/xiaochu.mp3" type="audio/mpeg">
	</audio>
</div>
	
<div id="divSnow-1" class="htmleaf-content canvas-1"></div>
<script src="zui/lib/jquery/jquery.js"></script>
<script src="zui/js/zui.min.js"></script>
<script src="zui/js/common.js"></script>
<script src="js/Websnowjq.js"></script>
<script src="js/hammer.min.js"></script>
<script src="js/app.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("#divSnow-1").websnowjq();
	$('#share').click(function() {
		$('.an-share-wk').addClass('active');
	});
	$('.an-share-wk').click(function() {
		$('.an-share-wk').removeClass('active');
	});
	$("#btnStart").click(function() {
		$.ajax({
		  type:'post',
		  url:'ajax.php',
		  data:{'type':'2','openid':'<?=$openid?>','nickname':'<?=$wx_nickname?>','headimgurl':'<?=$wx_headimgurl?>','belong':'<?=$belong?>'},
          dataType: 'json',
		  success:function(data){
			  if (data.type==2){
				new $.zui.Messager(data.info, {
				type: 'danger',
				placement: 'center'
				}).show();
				$("#startHeart").html(data.heart);
				$("#startLayer").hide();
				DDP.play(true);
				DDP.cleanOut();
			  }else{
				alert(data.info);
				window.location.href="index.php";
			  }
		  }
		});
	});
	$("#btnAgain").click(function() {
		$.ajax({
		  type:'post',
		  url:'ajax.php',
		  data:{'type':'2','openid':'<?=$openid?>','nickname':'<?=$wx_nickname?>','headimgurl':'<?=$wx_headimgurl?>','belong':'<?=$belong?>'},
          dataType: 'json',
		  success:function(data){
			  if (data.type==2){
				new $.zui.Messager(data.info, {
				type: 'danger',
				placement: 'center'
				}).show();
				$("#startHeart").html(data.heart);
				$("#overLayer").hide();
				DDP.play();
			  }else{
				alert(data.info);
				window.location.href="index.php";
			  }
		  }
		});
	});
});
function wx_game_start(){//开始

};
function wx_game_over(e){//结束
	var score = e;
	$.ajax({
	  type:'post',
	  url:'ajax.php',
	  data:{'type':'1','score':score,'openid':'<?=$openid?>','nickname':'<?=$wx_nickname?>','headimgurl':'<?=$wx_headimgurl?>'},
	  dataType: 'json',
	  success:function(data){
		  if (data.type==1){
			$('.an-victory-wz p').html('当前得分'+data.score+'，当前排名'+data.ranking);
			$('.an-victory-wk').addClass('active');
		  }else{
			new $.zui.Messager(data.info, {
			placement: 'center'
			}).show();
		  }
	  }
	});
};
function wx_game_move(){//移动
	$('#music_move').get(0).play();
};
function wx_game_error(){//错误
	$('#music_error').get(0).play();
};
function wx_game_remove(){//消除
	$('#music_remove').get(0).play();
};
</script>
</body>
</html>